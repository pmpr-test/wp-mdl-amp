<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675fab8d3a2b3             |
    |_______________________________________|
*/
ype html>
<html amp ⚡ <?php  language_attributes(); ?>>
<head>
	<meta charset="<?php  bloginfo("\143\150\141\162\x73\x65\164"); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<?php  do_action("\141\x6d\x70\x5f\167\x70\137\150\145\x61\x64"); ?>
</head>
<body <?php  body_class(); ?>>
<?php  pmpr_do_action("\x61\155\160\137\x62\157\x64\x79\137\157\160\145\156");
