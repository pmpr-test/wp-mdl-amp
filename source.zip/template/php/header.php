<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc50fe389f             |
    |_______________________________________|
*/
ype html>
<html amp ⚡ <?php  language_attributes(); ?>>
<head>
	<meta charset="<?php  bloginfo("\x63\150\x61\162\x73\x65\x74"); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<?php  do_action("\141\155\x70\137\167\160\137\150\x65\141\x64"); ?>
</head>
<body <?php  body_class(); ?>>
<?php  pmpr_do_action("\141\x6d\160\x5f\142\157\144\171\137\x6f\160\x65\156");
