<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67915122a3872             |
    |_______________________________________|
*/
ype html>
<html amp ⚡ <?php  language_attributes(); ?>>
<head>
	<meta charset="<?php  bloginfo("\143\150\141\x72\163\145\x74"); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<?php  do_action("\141\155\160\137\167\x70\x5f\150\145\141\144"); ?>
</head>
<body <?php  body_class(); ?>>
<?php  pmpr_do_action("\x61\155\160\137\142\x6f\x64\x79\x5f\157\x70\x65\156");
