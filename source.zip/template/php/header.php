<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517576a58f             |
    |_______________________________________|
*/
ype html>
<html amp ⚡ <?php  language_attributes(); ?>>
<head>
	<meta charset="<?php  bloginfo("\143\150\x61\162\163\x65\x74"); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<?php  do_action("\141\x6d\160\137\167\160\x5f\150\x65\141\144"); ?>
</head>
<body <?php  body_class(); ?>>
<?php  pmpr_do_action("\141\155\160\137\142\x6f\144\x79\x5f\x6f\160\145\x6e");
