<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675fab518eb3b             |
    |_______________________________________|
*/
ype html>
<html amp ⚡ <?php  language_attributes(); ?>>
<head>
	<meta charset="<?php  bloginfo("\143\x68\141\162\163\x65\x74"); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<?php  do_action("\141\x6d\x70\137\167\160\137\150\145\x61\144"); ?>
</head>
<body <?php  body_class(); ?>>
<?php  pmpr_do_action("\141\155\160\137\142\x6f\x64\171\137\x6f\x70\145\x6e");
