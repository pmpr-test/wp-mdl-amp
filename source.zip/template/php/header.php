<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5e78ceff1c             |
    |_______________________________________|
*/
ype html>
<html amp ⚡ <?php  language_attributes(); ?>>
<head>
	<meta charset="<?php  bloginfo("\143\x68\141\x72\163\x65\x74"); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<?php  do_action("\141\x6d\160\137\167\160\x5f\150\145\141\144"); ?>
</head>
<body <?php  body_class(); ?>>
<?php  pmpr_do_action("\141\155\160\x5f\142\x6f\x64\171\137\157\x70\x65\156");
