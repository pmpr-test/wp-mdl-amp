<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8e79a63e             |
    |_______________________________________|
*/
ype html>
<html amp ⚡ <?php  language_attributes(); ?>>
<head>
	<meta charset="<?php  bloginfo("\143\x68\141\162\x73\145\164"); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<?php  do_action("\141\x6d\160\137\x77\160\x5f\x68\145\x61\144"); ?>
</head>
<body <?php  body_class(); ?>>
<?php  pmpr_do_action("\x61\155\160\137\x62\157\144\x79\x5f\x6f\x70\145\x6e");
