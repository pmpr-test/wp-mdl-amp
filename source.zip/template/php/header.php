<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4ac081143             |
    |_______________________________________|
*/
ype html>
<html amp ⚡ <?php  language_attributes(); ?>>
<head>
	<meta charset="<?php  bloginfo("\143\x68\x61\x72\x73\145\164"); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<?php  do_action("\141\x6d\160\x5f\167\x70\x5f\x68\x65\x61\144"); ?>
</head>
<body <?php  body_class(); ?>>
<?php  pmpr_do_action("\141\155\160\137\x62\157\x64\171\137\x6f\160\x65\156");
