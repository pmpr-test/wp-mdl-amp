<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6ef23c92             |
    |_______________________________________|
*/
ype html>
<html amp ⚡ <?php  language_attributes(); ?>>
<head>
	<meta charset="<?php  bloginfo("\x63\x68\x61\162\x73\x65\164"); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<?php  do_action("\x61\x6d\160\x5f\x77\160\x5f\150\x65\x61\x64"); ?>
</head>
<body <?php  body_class(); ?>>
<?php  pmpr_do_action("\141\x6d\x70\137\x62\x6f\x64\171\137\x6f\160\x65\156");
