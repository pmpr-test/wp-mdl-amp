<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d97ef2c6c3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\60\56\61"; const wcwemgogyesywcww = "\150\x74\164\160\x73\72\x2f\x2f\x63\144\x6e\x2e\x61\x6d\160\x70\162\x6f\152\x65\x63\x74\x2e\x6f\x72\x67\x2f\166\60"; use CommonTrait; }
