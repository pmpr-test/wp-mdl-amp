<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670517576a58f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\60\56\x31"; const wcwemgogyesywcww = "\x68\164\164\160\163\72\57\x2f\143\x64\156\x2e\x61\x6d\160\160\162\157\152\145\143\164\56\x6f\162\147\x2f\x76\60"; use CommonTrait; }
