<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757f056c37a3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\60\56\x31"; const wcwemgogyesywcww = "\x68\164\164\160\x73\x3a\x2f\x2f\x63\144\x6e\56\x61\155\x70\x70\x72\157\x6a\x65\x63\x74\x2e\157\x72\147\57\x76\x30"; use CommonTrait; }
