<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec44320c4             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\x30\x2e\x31"; const wcwemgogyesywcww = "\x68\164\164\x70\163\72\x2f\57\143\x64\x6e\56\x61\x6d\160\x70\x72\x6f\x6a\145\x63\x74\56\157\162\x67\57\x76\60"; use CommonTrait; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
