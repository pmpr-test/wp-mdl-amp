<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757f0d741e95             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\x30\x2e\x31"; const wcwemgogyesywcww = "\x68\164\x74\160\163\x3a\x2f\57\143\x64\156\56\141\x6d\x70\160\162\157\152\x65\x63\164\x2e\x6f\162\x67\x2f\166\x30"; use CommonTrait; }
