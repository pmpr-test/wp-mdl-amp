<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4ac081143             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\60\x2e\61"; const wcwemgogyesywcww = "\150\164\x74\160\x73\72\x2f\57\x63\x64\156\x2e\x61\155\x70\160\x72\157\x6a\145\x63\x74\56\x6f\x72\x67\57\x76\x30"; use CommonTrait; }
