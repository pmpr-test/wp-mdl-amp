<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8e79a63e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\60\x2e\61"; const wcwemgogyesywcww = "\x68\164\164\160\x73\72\x2f\57\143\x64\156\56\x61\155\160\x70\162\x6f\x6a\x65\143\164\56\x6f\162\147\x2f\x76\x30"; use CommonTrait; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }
