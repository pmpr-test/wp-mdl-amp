<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675f1d09a38ab             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\x30\x2e\61"; const wcwemgogyesywcww = "\150\x74\164\160\163\x3a\57\x2f\x63\x64\x6e\56\141\155\160\160\x72\157\x6a\145\143\164\56\x6f\162\x67\x2f\x76\x30"; use CommonTrait; }
