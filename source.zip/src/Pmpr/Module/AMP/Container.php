<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d71f11f2             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\x30\x2e\x31"; const wcwemgogyesywcww = "\150\164\x74\160\163\72\x2f\x2f\143\x64\x6e\56\x61\x6d\x70\160\x72\157\x6a\x65\x63\164\x2e\157\x72\x67\57\x76\60"; use CommonTrait; }
