<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675fab8d3a2b3             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\60\56\x31"; const wcwemgogyesywcww = "\150\164\164\160\x73\72\57\x2f\143\x64\x6e\56\x61\155\160\160\162\x6f\152\x65\143\164\x2e\157\162\x67\x2f\166\60"; use CommonTrait; }
