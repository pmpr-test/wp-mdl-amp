<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675fab518eb3b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\60\x2e\61"; const wcwemgogyesywcww = "\150\164\x74\160\163\72\57\57\143\x64\x6e\56\x61\155\x70\160\162\157\152\145\143\x74\56\157\x72\x67\57\166\x30"; use CommonTrait; }
