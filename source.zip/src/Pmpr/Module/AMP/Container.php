<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d46b52a43e             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\60\56\x31"; const wcwemgogyesywcww = "\x68\164\x74\160\163\x3a\x2f\x2f\143\144\x6e\56\141\155\x70\160\x72\157\152\145\x63\164\56\157\x72\x67\x2f\x76\x30"; use CommonTrait; }
