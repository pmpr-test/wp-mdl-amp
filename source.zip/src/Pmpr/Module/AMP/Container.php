<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d001f9a895             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\60\x2e\61"; const wcwemgogyesywcww = "\150\x74\x74\160\163\x3a\x2f\x2f\143\144\x6e\56\x61\155\160\x70\x72\157\152\145\143\164\56\x6f\162\x67\57\166\x30"; use CommonTrait; }
