<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc50fe389f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\x30\56\x31"; const wcwemgogyesywcww = "\150\x74\x74\160\163\x3a\57\57\143\144\x6e\x2e\x61\155\x70\x70\x72\157\x6a\145\143\164\56\157\162\x67\57\166\x30"; use CommonTrait; }
