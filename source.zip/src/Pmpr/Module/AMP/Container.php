<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67915122a3872             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\x30\x2e\61"; const wcwemgogyesywcww = "\x68\164\164\160\x73\x3a\x2f\57\x63\144\156\56\x61\x6d\x70\x70\x72\x6f\x6a\x65\143\164\x2e\157\x72\x67\x2f\x76\x30"; use CommonTrait; }
