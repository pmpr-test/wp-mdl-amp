<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             67705d71f11f2             |
    |_______________________________________|
*/
 use Pmpr\Module\AMP\AMP; AMP::symcgieuakksimmu(); if (!function_exists("\x69\x73\137\x61\155\x70")) { function is_amp() { return AMP::symcgieuakksimmu()->oywyqcgumoecwoga(); } } if (!function_exists("\x69\x73\x5f\141\155\160\137\x65\156\144\160\157\151\x6e\x74")) { function is_amp_endpoint() { return AMP::symcgieuakksimmu()->smowememmgeukwki(); } }
