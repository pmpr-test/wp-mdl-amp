<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8e79a63e             |
    |_______________________________________|
*/
 use Pmpr\Module\AMP\AMP; AMP::symcgieuakksimmu(); if (!function_exists("\x69\163\x5f\x61\x6d\160")) { function is_amp() { return AMP::symcgieuakksimmu()->oywyqcgumoecwoga(); } } if (!function_exists("\x69\x73\x5f\x61\x6d\160\137\145\x6e\x64\x70\x6f\151\156\x74")) { function is_amp_endpoint() { return AMP::symcgieuakksimmu()->smowememmgeukwki(); } }
