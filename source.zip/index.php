<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec44320c4             |
    |_______________________________________|
*/
 use Pmpr\Module\AMP\AMP; AMP::symcgieuakksimmu(); if (!function_exists("\x69\x73\137\141\155\160")) { function is_amp() { return AMP::symcgieuakksimmu()->oywyqcgumoecwoga(); } } if (!function_exists("\151\163\137\141\x6d\x70\x5f\145\156\x64\160\157\x69\x6e\x74")) { function is_amp_endpoint() { return AMP::symcgieuakksimmu()->smowememmgeukwki(); } }
